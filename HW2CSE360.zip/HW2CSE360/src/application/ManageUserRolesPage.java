package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import databasePart1.DatabaseHelper;

import java.util.List;

public class ManageUserRolesPage {
    private final DatabaseHelper databaseHelper;

    public ManageUserRolesPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label titleLabel = new Label("Manage User Roles");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        layout.getChildren().add(titleLabel);

        List<String[]> usersAndRoles = databaseHelper.getAllUsernamesAndRoles();
        for (String[] user : usersAndRoles) {
            VBox userBox = new VBox(10);
            Label userNameLabel = new Label(user[0] + " - " + user[1]);

            ComboBox<String> roleComboBox = new ComboBox<>();
            roleComboBox.getItems().addAll("admin", "student", "instructor", "staff", "reviewer");
            roleComboBox.setValue(user[1]);

            Button updateButton = new Button("Update Role");
            updateButton.setOnAction(e -> {
                String newRole = roleComboBox.getValue();

                try {
                    if ("admin".equals(user[1]) && !"admin".equals(newRole) && databaseHelper.countAdmins() <= 1) {
                        showAlert("Error", "There must always be at least one admin user.");
                    } else {
                        databaseHelper.updateUserRole(user[0], newRole);
                        userNameLabel.setText(user[0] + " - " + newRole);
                        showAlert("Success", "Role updated successfully.");
                    }
                } catch (Exception ex) {
                    showAlert("Error", "An error occurred while updating the role.");
                }
            });

            userBox.getChildren().addAll(userNameLabel, roleComboBox, updateButton);
            layout.getChildren().add(userBox);
        }

        Button backButton = new Button("Back to Manage Users");
        backButton.setOnAction(e -> new ListUsersPage(databaseHelper).show(primaryStage));
        layout.getChildren().add(backButton); 
        
        primaryStage.setScene(new Scene(layout, 800, 600));
        primaryStage.setTitle("Manage User Roles");
        primaryStage.show();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}