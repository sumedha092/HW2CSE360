package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;
import databasePart1.*;

public class RoleSelectionPage {
    private User user;
    private Stage mainStage;
    private DatabaseHelper databaseHelper;
    private QuestionAnswerDB questionAnswerDB;


    public RoleSelectionPage(User user, Stage stage, DatabaseHelper databaseHelper,QuestionAnswerDB questionAnswerDB) throws SQLException {
        this.databaseHelper = databaseHelper;
		this.questionAnswerDB = new QuestionAnswerDB();
        this.user = user;
        this.mainStage = stage;
    }

    public void showRoleSelection(List<String> roles) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label title = new Label("Select Your Role:");
        ComboBox<String> roleDropdown = new ComboBox<>();
        roleDropdown.getItems().addAll(roles);

        Button selectButton = new Button("Continue");
        selectButton.setOnAction(e -> {
            String chosenRole = roleDropdown.getValue();
            if (chosenRole != null) {
                user.setRole(chosenRole);
                openHomePage(chosenRole);
            }
        });

        layout.getChildren().addAll(title, roleDropdown, selectButton);
        mainStage.setScene(new Scene(layout, 400, 200));
        mainStage.show();
    }

    public void openHomePage(String role) {
        if (role.equals("Admin")) {
            new AdminHomePage(databaseHelper).show(mainStage);
        } else {
            new UserHomePage(databaseHelper, questionAnswerDB).show(mainStage);
        }
    }
}